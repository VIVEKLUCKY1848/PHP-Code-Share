<?php

class Common_Functions_Helper_Data extends Mage_Core_Helper_Abstract
{

	public function dump_to_console($data){

		if (is_array($data) || is_object($data))
	{
		echo ("<script>console.log('PHP: " . json_encode($data) . "');</script>");
	}
	else
	{
		echo ("<script>console.log('PHP: " . $data . "');</script>");
	}
	exit;

	}

	public function parse_url_params($qry)
	{
		$result = array();
		if(strpos($qry,'action') === false):
			if(strpos($qry,'=')) {
				if(strpos($qry,'?')!==false) {
					$q = parse_url($qry);
					$qry = $q['query'];
				}
			}else {
				return false;
			}
			foreach (explode('&', $qry) as $couple) {
				list ($key, $val) = explode('=', $couple);
				$result[$key] = $val;
			}
			return empty($result) ? false : $result;
		else:
			return false;
		endif;
	}
}
