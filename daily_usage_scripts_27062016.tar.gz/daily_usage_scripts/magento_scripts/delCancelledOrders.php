<?php
error_reporting(E_ALL);
require_once './app/Mage.php';
umask(0);
Mage::app();
$collection = Mage::getResourceModel('sales/order_collection')
							->addAttributeToSelect('*')
							->addFieldToFilter('status', 'canceled')
							->addFieldToFilter('customer_firstname', array('like' => '%test%'))
							->load();

echo $collection->getSelect();
							
## echo "<pre/>";print_r($collection->getData());die;

$db = Mage::getSingleton('core/resource')->getConnection('core_write');
$sales_flat_order_grid= Mage::getSingleton('core/resource')->getTableName('sales_flat_order_grid');
$order_increment_id = $order->getIncrementId();
if($order_increment_id){
    $db->query("DELETE FROM ".$sales_flat_order_grid." WHERE increment_id='".mysql_escape_string($order_increment_id)."'");
}

foreach ($collection as $col) {
    try {
        $col->delete();
        $db = Mage::getSingleton('core/resource')->getConnection('core_write');
        $sales_flat_order_grid= Mage::getSingleton('core/resource')->getTableName('sales_flat_order_grid');
        $order_increment_id = $order->getIncrementId();
        if($order_increment_id && $col->getIncrementId() != $order_increment_id) {
            $db->query("DELETE FROM ".$sales_flat_order_grid." WHERE increment_id='".mysql_escape_string($order_increment_id)."'");
        }
        echo $order_increment_id." order is now deleted!!!";
    } catch (Exception $e) {
        throw $e;
    }
}


/*tar -zcvf ooberpad_14-12-2015.tar.gz --exclude='*.tar' --exclude='*.log' magento/

rm -rf magento/var/cache/*
rm -rf magento/var/session/*

tar -zcvf ooberpad_14-12-2015.tar.gz --exclude='*.tar' --exclude='*.log' magento/

scp root@128.199.104.39:/var/www/html/ooberpad_14-12-2015.tar.gz /home/ubuntu/Downloads

scp root@128.199.104.39:ooberpad_14-12-2015.tar.gz /home/ubuntu/Downloads
*/
