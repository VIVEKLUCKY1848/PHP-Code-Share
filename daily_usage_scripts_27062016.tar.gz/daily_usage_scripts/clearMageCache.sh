SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )";
ROOT_DIR=$SCRIPT_DIR;
## ${BASEPATH%%/}/subFold1
rm -rfv ${ROOT_DIR%%}/var/cache/*
rm -rfv ${ROOT_DIR%%}/var/session/*
rm -rfv ${ROOT_DIR%%}/var/report/*
rm -rfv ${ROOT_DIR%%}/media/catalog/product/cache/*
kill -9 $PPID;
