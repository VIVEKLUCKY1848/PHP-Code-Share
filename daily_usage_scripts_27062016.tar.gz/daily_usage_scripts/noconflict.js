jQuery.noConflict();
//var $j = jQuery.noConflict();
//var $jqq = jQuery.noConflict();
//$ = window.$;
//window.jQuery = window.$ = jQuery;
//_jQuery = window.jQuery, 
// Map over the $ in case of overwrite
//_$ = window.$,
