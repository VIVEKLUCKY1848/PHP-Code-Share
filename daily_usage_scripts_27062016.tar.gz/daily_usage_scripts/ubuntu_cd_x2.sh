up() {
	local path i
	for (( i=0; i < $1; i++ )); do
		path+=../
	done
	cd "$path"
}
