## Import MySQL DB from command line start
mysql -u <username> -p <dbname> < <path_to_script.sql>
password: <password>
### Example
mysql -u psuser -p wex0004_dbb < fullpath/to/wex0004_dbb.sql
password: internet2014
## Import MySQL DB from command line finish
