var g = 12;
(function(m){
  var y = prompt("Enter a value!!!");
  alert(g+parseInt(y)-m);
})(56);

alert(y);
alert(g);
