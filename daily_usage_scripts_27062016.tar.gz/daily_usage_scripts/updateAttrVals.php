<?php
ini_set('display_errors',1);
error_reporting(E_ALL);
require_once("app/Mage.php");
umask(0);
Mage::app('default');

$connection = Mage::getSingleton('core/resource')->getConnection('core_read');
$select = $connection->select()->from('cities', array('*'));
$cities = $connection->fetchAll($select);

$i = 1;
foreach($cities as $city):
	$newCities[$i] = array($city['city']);
	$i++;
endforeach;

Mage::app()->setCurrentStore(Mage_Core_Model_App::ADMIN_STORE_ID);

$arg_attribute = 'by_city';
$arg_value1 = $newCities;

$attribute = Mage::getModel('eav/config')->getAttribute('catalog_product', 'by_city');

$attribute_model = Mage::getModel('eav/entity_attribute');
$attribute_options_model= Mage::getModel('eav/entity_attribute_source_table');
$attribute_code = $attribute_model->getIdByCode('catalog_product', 'by_city');
$attribute = $attribute_model->load($attribute_code);
$attribute_table = $attribute_options_model->setAttribute($attribute);
$options = $attribute_options_model->getAllOptions(false);

foreach($newCities as $key => $val):

	echo "Inserting city ".$val[0]."<br />";

	$value['option'] = array($val[0], $val[0]);
	$result = array('value' => $value);
	$attribute->setData('option',$result);
	$attribute->save();

endforeach;

exit;die;

$attr_model = Mage::getModel('catalog/resource_eav_attribute');
$attr = $attr_model->loadByCode('catalog_product', $arg_attribute);
$attr_id = $attr->getAttributeId();

foreach($arg_value as $key => $val):

$option['attribute_id'] = $attr_id;
## $option['value']['any_option_name'][0] = $arg_value;
echo "Inserting value ".$val[0]."<br />";
$option['value'][$key][0] = $val[0];

$setup = new Mage_Eav_Model_Entity_Setup('core_setup');
$setup->addAttributeOption($option);

endforeach;
