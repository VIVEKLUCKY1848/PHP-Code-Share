<?php
## Check if a value exists in a multi-dimensional array begin
function in_array_r($needle, $haystack, $strict = false) {
	foreach ($haystack as $item) {
		if (($strict ? $item === $needle : $item == $needle) || (is_array($item) && in_array_r($needle, $item, $strict))) {
			return true;
		}
	}
	return false;
}
## Check if a value exists in a multi-dimensional array end

## Check if a value exists in a multi-dimensional array start
function in_array_r($needle, $haystack, $strict = false) {
	foreach ($haystack as $item) {
		if (($strict ? $item === $needle : $item == $needle) || (is_array($item) && in_array_r($needle, $item, $strict))) {
			return true;
		}
	}
	return false;
}
## Check if a value exists in a multi-dimensional array finish

## PHP Extract Link URL & Label from HTML Content start
### Below line fetches only URLs from HTML Links
## preg_match_all('~<a(.*?)href="([^"]+)"(.*?)>~', $menuBlockContent, $linkUrls);
preg_match_all("/\<a.*href=\"(.*?)\".*?\>(.*)\<\/a\>+/", $anyHtmlContent, $linkData, PREG_SET_ORDER);
var_dump($linkData);
## PHP Extract Link URL & Label from HTML Content finish

## PHP Extract content inside <body> tags start
preg_match("/<body[^>]*>(.*?)<\/body>/is", $html, $matches);
$content = $matches[1];
## PHP Extract content inside <body> tags end

## Magento Zend Debug for debugging objects
Mage::log(
	$object->debug(), //Objects extending Varien_Object can use this
	Zend_Log::DEBUG,  //Log level
	'<filename>.log',         //Log file name; if blank, will use config value (system.log by default)
	true              //force logging regardless of config setting
);

Mage::log("Object Info: ".print_r($object->debug(), true), null, '<filename>.log');
Mage::log('Object Info:-'.Zend_Debug::dump($object, null, false), null, '<filename>.log');
?>
