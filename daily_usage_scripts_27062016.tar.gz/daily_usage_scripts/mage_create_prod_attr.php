<?php
## Initialize the installer object
$installer = $this;
$setup = new Mage_Eav_Model_Entity_Setup('core_setup');
$installer->startSetup();

## Specify attribute group
$installer->addAttributeGroup('catalog_product', 'Default', 'Prices', 1000);

## Add attribute
$installer->addAttribute('catalog_product', 'best_price', array(
  'group' => 'Prices',
  'label' => 'Guaranteed Best Price',
  'type' => 'int',
  'input' => 'boolean',
  'source' => 'eav/entity_attribute_source_boolean',
  'global' => Mage_Catalog_Model_Resource_Eav_Attribute::SCOPE_STORE,
  'visible' => true,
  'required' => true,
  'user_defined' => false,
  'unique' => false,
));

## Update remaining settings
$setup->updateAttribute('catalog_product', 'best_price', 'is_visible_on_front',true);
$setup->updateAttribute('catalog_product', 'best_price', 'is_searchable',true);
$setup->updateAttribute('catalog_product', 'best_price', 'is_filterable',true);
$setup->updateAttribute('catalog_product', 'best_price', 'is_visible_in_advanced_search',true);
$setup->updateAttribute('catalog_product', 'best_price', 'is_comparable',true);
$setup->updateAttribute('catalog_product', 'best_price', 'used_in_product_listing',true);
$setup->updateAttribute('catalog_product', 'best_price', 'used_for_sort_by',true);
$setup->updateAttribute('catalog_product', 'best_price', 'is_used_for_promo_rules',true);
$setup->updateAttribute('catalog_product', 'best_price', 'is_used_for_price_rules',true);

## End installer setup
$installer->endSetup();
