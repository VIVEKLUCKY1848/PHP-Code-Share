<?php
require_once 'Mage/Checkout/controllers/CartController.php';
class Custom_Ajax_IndexController extends Mage_Checkout_CartController
{
	public function addAction()
	{
		$cart = $this->_getCart();
		$params = $this->getRequest()->getParams();
		if($params['isAjax'] == 1) {
			$response = array();
			try {
				if (isset($params['qty'])) {
					$filter = new Zend_Filter_LocalizedToNormalized(
						array('locale' => Mage::app()->getLocale()->getLocaleCode())
					);
					$params['qty'] = $filter->filter($params['qty']);
					$response['qty'] = $params['qty'];
				}
				else
				{
					$response['qty'] = 1;
				}
				$product = $this->_initProduct();
				$related = $this->getRequest()->getParam('related_product');
				/**
				 * Check product availability
				 */
				if (!$product) {
					$response['status'] = 'ERROR';
					$response['message'] = $this->__('Unable to find Product ID');
				}
				$cart->addProduct($product, $params);
				if (!empty($related)) {
					$cart->addProductsByIds(explode(',', $related));
				}
				$cart->save();
				$this->_getSession()->setCartWasUpdated(true);
				$quote = Mage::getSingleton('checkout/cart')->getQuote();
				$item = $quote->getItemByProduct($product);
				if ($item !== false) {
					$response['cardId'] = $item->getId();
				} else {
					$response['cardId'] = '';
					$session= Mage::getSingleton('checkout/session');
					foreach($session->getQuote()->getAllItems() as $item) {
						$response['cardId'] = $item->getId();
						// Now you have a full loaded Product Object.
					}
				}
				/**
				 * @todo remove wishlist observer processAddToCart
				 */
				Mage::dispatchEvent('checkout_cart_add_product_complete',
					array('product' => $product, 'request' => $this->getRequest(), 'response' => $this->getResponse())
				);
				if (!$cart->getQuote()->getHasError()) {
					$message = $this->__('%s was added to your shopping cart.', Mage::helper('core')->htmlEscape($product->getName()));
					$response['status'] = 'SUCCESS';
					$response['message'] = $message;
					//New Code Here
					$this->loadLayout();
					$toplink = $this->getLayout()->getBlock('top.links')->toHtml();
					## $sidebar_block = $this->getLayout()->getBlock('cart_sidebar');
					$sidebar_block = $this->getLayout()->getBlock('cart_sidebar_tab');
					## $sidebar_block = strip_tags($sidebar_block, '<ol>');
					//preg_match_all('/<MY_TAG>(.*?)<\/MY_TAG>/s', $sidebar_block, $matches);
					Mage::register('referrer_url', $this->_getRefererUrl());
					$sidebar = $sidebar_block->toHtml();
					$response['toplink'] = $toplink;
					$response['sidebar'] = $sidebar;
				}
			} catch (Mage_Core_Exception $e) {
				$msg = "";
				if ($this->_getSession()->getUseNotice(true)) {
					$msg = $e->getMessage();
				} else {
					$messages = array_unique(explode("\n", $e->getMessage()));
					foreach ($messages as $message) {
						$msg .= $message.'<br/>';
					}
				}
				$response['status'] = 'ERROR';
				$response['message'] = $msg;
			} catch (Exception $e) {
				$response['status'] = 'ERROR';
				$response['message'] = $this->__('Cannot add the item to shopping cart.');
				Mage::logException($e);
			}
			//print_r($response);
			$this->getResponse()->setBody(Mage::helper('core')->jsonEncode($response));
			return;
		} else {
			return parent::addAction();
		}
	}
	
	public function optionsAction() {
		$productId = $this->getRequest()->getParam('product_id');
		// Prepare helper and params
		$viewHelper = Mage::helper('catalog/product_view');
		$params = new Varien_Object();
		$params->setCategoryId(false);
		$params->setSpecifyOptions(false);
		// Render page
		try {
			$viewHelper->prepareAndRender($productId, $this, $params);
		} catch (Exception $e) {
			if ($e->getCode() == $viewHelper->ERR_NO_PRODUCT_LOADED) {
				if (isset($_GET['store'])  && !$this->getResponse()->isRedirect()) {
					$this->_redirect('');
				} elseif (!$this->getResponse()->isRedirect()) {
					$this->_forward('noRoute');
				}
			} else {
				Mage::logException($e);
				$this->_forward('noRoute');
			}
		}
	}
	
	public function comparelistAction() {
		$this->loadLayout();
		$this->renderLayout();
	}
	
	public function deleteAction()
	{
		$params = $this->getRequest()->getParams();
		$response['status'] = 'ERROR';
		$response['sidebar'] = '';
		$response['toplink'] = '';
		$response['message'] = $this->__('Item is not removed, please try again');
		if($params['isAjax'] == 1)
		{
			$id = (int) $params['id'];
			if ($id)
			{
				try
				{
					$this->_getCart()->removeItem($id)->save();
					$response['cartid'] = $id;
					$this->_getSession()->setCartWasUpdated(true);
					Mage::dispatchEvent('checkout_cart_add_product_complete',
						array('product' => $product, 'request' => $this->getRequest(), 'response' => $this->getResponse())
					);
					$this->loadLayout();
					$toplink = $this->getLayout()->getBlock('top.links')->toHtml();
					$sidebar_block = $this->getLayout()->getBlock('cart_sidebar');
					Mage::register('referrer_url', $this->_getRefererUrl());
					$sidebar = $sidebar_block->toHtml();
					$response['sidebar'] = $sidebar;
					$response['toplink'] = $toplink;
					$response['message'] =  $this->__('Item has been deleted successfully');
					$response['status'] = 1;
				}
				catch (Exception $e)
				{
					$response['message'] = $this->__('Cannot remove the item.');
					$response['status'] = 'ERROR';
				}
			}
		}
		//echo "respnos=<br>"; print_r($response);
		//exit;
		$this->getResponse()->setBody(Mage::helper('core')->jsonEncode($response));
		return;
   }
}
