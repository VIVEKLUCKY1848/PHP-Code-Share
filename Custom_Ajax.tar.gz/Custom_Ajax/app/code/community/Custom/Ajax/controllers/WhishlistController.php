<?php
class Custom_Ajax_WhishlistController extends Mage_Wishlist_Controller_Abstract //Mage_Core_Controller_Front_Action
{

	public function compareAction(){
		$response = array();

		if ($productId = (int) $this->getRequest()->getParam('product')) {
			$product = Mage::getModel('catalog/product')
			->setStoreId(Mage::app()->getStore()->getId())
			->load($productId);

			if ($product->getId()/* && !$product->isSuper()*/) {
				Mage::getSingleton('catalog/product_compare_list')->addProduct($product);
				$response['status'] = 'SUCCESS';
				$response['message'] = $this->__('The product %s has been added to comparison list.', Mage::helper('core')->escapeHtml($product->getName()));
				Mage::register('referrer_url', $this->_getRefererUrl());
				Mage::helper('catalog/product_compare')->calculate();
				Mage::dispatchEvent('catalog_product_compare_add_product', array('product'=>$product));
				$this->loadLayout();
				
                                $sidebar_block = $this->getLayout()->getBlock('catalog.compare.sidebar');
				$sidebar_block->setTemplate('ajax/catalog/product/compare/sidebar.phtml');
				$sidebar = $sidebar_block->toHtml();
				$response['sidebar_tab'] = $sidebar;
                                
                                $sidebar_block_main = $this->getLayout()->getBlock('ajax.catalog.compare.sidebar');
				$sidebar_block_main->setTemplate('/ajax/catalog/product/compare/sidebar_main.phtml');
				$sidebar_main = $sidebar_block_main->toHtml();
                                $response['sidebar_main'] = $sidebar_main;
			}
		}
		$this->getResponse()->setBody(Mage::helper('core')->jsonEncode($response));
		return;
	}



	protected function _getWishlist()
	{
		$wishlist = Mage::registry('wishlist');
		if ($wishlist) {
			return $wishlist;
		}

		try {
			$wishlist = Mage::getModel('wishlist/wishlist')
			->loadByCustomer(Mage::getSingleton('customer/session')->getCustomer(), true);
			Mage::register('wishlist', $wishlist);
		} catch (Mage_Core_Exception $e) {
			Mage::getSingleton('wishlist/session')->addError($e->getMessage());
		} catch (Exception $e) {
			Mage::getSingleton('wishlist/session')->addException($e,
			Mage::helper('wishlist')->__('Cannot create wishlist.')
			);
			return false;
		}

		return $wishlist;
	}
        
public function removeitemAction()
{
    $response = array();
    $response['status'] = 'ERROR';
    $response['message'] = $this->__('Unable removed from comparison list. Please try again');
    if ($productId = (int) $this->getRequest()->getParam('product')) 
    {
      try
      {
        $product = Mage::getModel('catalog/product')
                ->setStoreId(Mage::app()->getStore()->getId())
                ->load($productId);
    
        if($product->getId())
         {
                /** @var $item Mage_Catalog_Model_Product_Compare_Item */
                $item = Mage::getModel('catalog/product_compare_item');
               
                  if(Mage::getSingleton('customer/session')->isLoggedIn()) {
                    $item->addCustomerData(Mage::getSingleton('customer/session')->getCustomer());
                } elseif ($this->_customerId) {
                    $item->addCustomerData(
                        Mage::getModel('customer/customer')->load($this->_customerId)
                    );
                } else {
                    $item->addVisitorId(Mage::getSingleton('log/visitor')->getId());
                }
                

                $item->loadByProduct($product);   

                if($item->getId()) {
                    
                    $item->delete();
                    
                    $_helper =  Mage::helper('catalog/product_compare');
                    
                    $response['totalItem'] =  count($_helper->getItemCollection());
                    $response['status'] = 'SUCCESS';
		    $response['message'] = $this->__('The product %s has been removed from comparison list.', Mage::helper('core')->escapeHtml($product->getName()));
		
                    Mage::dispatchEvent('catalog_product_compare_remove_product', array('product'=>$item));
                    Mage::helper('catalog/product_compare')->calculate();
                    
                    $this->loadLayout();
		    $sidebar_block = $this->getLayout()->getBlock('catalog.compare.sidebar');
		    $sidebar_block->setTemplate('ajax/catalog/product/compare/sidebar.phtml');
		    $sidebar = $sidebar_block->toHtml();
		    $response['sidebar_tab'] = $sidebar;
                                
                    $sidebar_block_main = $this->getLayout()->getBlock('ajax.catalog.compare.sidebar');
		    $sidebar_block_main->setTemplate('/ajax/catalog/product/compare/sidebar_main.phtml');
		    $sidebar_main = $sidebar_block_main->toHtml();
                    $response['sidebar_main'] = $sidebar_main;
                    
                   
                }
            }
       }
       catch (Mage_Core_Exception $e)
       {
         $response['status'] = 'ERROR';
         $response['message'] = $this->__('An error occurred while removing item from comparison: %s', $e->getMessage()); 
       }
    }

   $this->getResponse()->setBody(Mage::helper('core')->jsonEncode($response));
   return;    
}


 /**
     * Remove all items from comparison list
     */
public function clearcompareAction()
{
    $response['status'] = 'ERROR'; 
    $response['message'] = $this->__('Unable removed from comparison list. Please try again');
    try
    {
        $items = Mage::getResourceModel('catalog/product_compare_item_collection');

        if (Mage::getSingleton('customer/session')->isLoggedIn()) {
            $items->setCustomerId(Mage::getSingleton('customer/session')->getCustomerId());
        } elseif ($this->_customerId) {
            $items->setCustomerId($this->_customerId);
        } else {
            $items->setVisitorId(Mage::getSingleton('log/visitor')->getId());
        }

        /** @var $session Mage_Catalog_Model_Session */
       // $session = Mage::getSingleton('catalog/session');

        try 
        {
             if($items->clear())
             {     
                $response['status'] = 'SUCCESS';
                $response['message'] = $this->__('The comparison list was cleared.'); 
                 Mage::dispatchEvent('catalog_product_compare_remove_product', array('product'=>$item));
                Mage::helper('catalog/product_compare')->calculate();
             
                $this->loadLayout();
                $sidebar_block = $this->getLayout()->getBlock('catalog.compare.sidebar');
                $sidebar_block->setTemplate('ajax/catalog/product/compare/sidebar.phtml');
                $sidebar = $sidebar_block->toHtml();
                $response['sidebar_tab'] = $sidebar;
                                
                $sidebar_block_main = $this->getLayout()->getBlock('catalog.compare.sidebar');
                $sidebar_block_main->setTemplate('/catalog/product/compare/sidebar.phtml');
                $sidebar_main = $sidebar_block_main->toHtml();
                $response['sidebar_main'] = $sidebar_main;
             }
             else
             {
                $response['status'] = 'SUCCESS';
                $response['message'] = $this->__('An error occurred while clearing comparison list.');  
             }
        }
        catch (Mage_Core_Exception $e)
        {
             $response['status'] = 'SUCCESS';
             $response['message'] = $this->__('An error occurred while removing item from comparison: %s',$e->getMessage()); 
            
           // $session->addError($e->getMessage());
        } catch (Exception $e)
        {
            $response['status'] = 'SUCCESS';
            $response['message'] = $this->__('An error occurred while clearing comparison list.'); 
            //$session->addException($e, $this->__('An error occurred while clearing comparison list.'));
        }

    }
    catch (Mage_Core_Exception $e)
    {
        $response['status'] = 'ERROR';
         $response['message'] = $this->__('An error occurred while removing item from comparison: %s', $e->getMessage());  
    }
  
   $this->getResponse()->setBody(Mage::helper('core')->jsonEncode($response));
   return; 
    
}
public function addAction()
	{
		$response = array();
		if (!Mage::getStoreConfigFlag('wishlist/general/active')) {
			$response['status'] = 'ERROR';
			$response['message'] = $this->__('Wishlist Has Been Disabled By Admin');
		}
		if(!Mage::getSingleton('customer/session')->isLoggedIn()){
			$response['status'] = 'ERROR';
			$response['message'] = $this->__('Please Login First');
		}

		if(empty($response)){
			$session = Mage::getSingleton('customer/session');
			$wishlist = $this->_getWishlist();
			if (!$wishlist) {
				$response['status'] = 'ERROR';
				$response['message'] = $this->__('Unable to Create Wishlist');
			}else{

				$productId = (int) $this->getRequest()->getParam('product');
                               	if (!$productId) {
					$response['status'] = 'ERROR';
					$response['message'] = $this->__('Product Not Found');
				}else{
					$product = Mage::getModel('catalog/product')->load($productId);
					if (!$product->getId() || !$product->isVisibleInCatalog()) {
						$response['status'] = 'ERROR';
						$response['message'] = $this->__('Cannot specify product.');
					}else{
						try {
							$requestParams = $this->getRequest()->getParams();
							$buyRequest = new Varien_Object($requestParams);

							$result = $wishlist->addNewItem($product, $buyRequest);
							if (is_string($result)) {
                                                            Mage::throwException($result);
							}
							if($wishlist->save());
                                                        {
                                                            $message = $this->__('%1$s has been added to your wishlist.', $product->getName(), $referer);
							$response['status'] = 'SUCCESS';
							$response['message'] = $message;
                                                        }
							Mage::dispatchEvent(
                				'wishlist_add_product',
							array(
			                    'wishlist'  => $wishlist,
			                    'product'   => $product,
			                    'item'      => $result
							)
							);

							Mage::helper('wishlist')->calculate();

							

							Mage::unregister('wishlist');

							$this->loadLayout();
							$toplink = $this->getLayout()->getBlock('top.links')->toHtml();
							$sidebar_block = $this->getLayout()->getBlock('ajax_wishlist_sidebar');
							$sidebar_block->setTemplate('ajax/wishlist/sidebar.phtml');
                                                        $sidebar = $sidebar_block->toHtml();
							$response['toplink'] = $toplink;
							$response['sidebar'] = $sidebar;
                                                        
                                                        
                                                        $sidebar_block_main = $this->getLayout()->getBlock('wishlist_sidebar_tab');
                                                        $sidebar_block_main->setTemplate('ajax/sidebar_wishlist.phtml');
                                                        $sidebar_main = $sidebar_block_main->toHtml();
                                                        $response['sidebar_main'] = $sidebar_main;
						}
						catch (Mage_Core_Exception $e) {
							$response['status'] = 'ERROR';
							$response['message'] = $this->__('An error occurred while adding item to wishlist: %s', $e->getMessage());
						}
						catch (Exception $e) {
							mage::log($e->getMessage());
							$response['status'] = 'ERROR';
							$response['message'] = $this->__('An error occurred while adding item to wishlist.');
						}
					}
				}
			}

		}
             //   print_r($response);
              //  exit;
		$this->getResponse()->setBody(Mage::helper('core')->jsonEncode($response));
		return;
	}        
public function deleteAction()
{
    
        $response = array();
	if (!Mage::getStoreConfigFlag('wishlist/general/active')) {
            $response['status'] = 'ERROR';
            $response['message'] = $this->__('Wishlist Has Been Disabled By Admin');
        }
        if(!Mage::getSingleton('customer/session')->isLoggedIn()){
            $response['status'] = 'ERROR';
            $response['message'] = $this->__('Please Login First');
        }
        
        if(empty($response))
        {
	   $session = Mage::getSingleton('customer/session');
           $id = (int) $this->getRequest()->getParam('item');
           $item = Mage::getModel('wishlist/item')->load($id);
//           $product = $item->getProduct();
                 
           if (!$item->getId())
              {
                $response['status'] = 'ERROR';
                $response['message'] = $this->__('Unable to delete Wishlist item');
              }
              
              $wishlist = $this->_getWishlist($item->getWishlistId());
                
              if (!$wishlist)
              {
		 $response['status'] = 'ERROR';
		 $response['message'] = $this->__('Unable to delete Wishlist item');
	      }
              else
              {
                 
		try
                {
                  $item->delete();
                  $wishlist->save();
                  
                  
                 // $product = Mage::getModel('catalog/product')->load($id);
                  
               //   Mage::dispatchEvent('wishlist_add_product',array('wishlist'=> $wishlist,'product'=> $product,'item'=> $result));
 		  Mage::helper('wishlist')->calculate();

                  $itemID = $this->getRequest()->getParam('item');
                   
		  $message = $this->__('item has been deleted to your wishlist.');
		  $response['status'] = 'SUCCESS';
		  $response['message'] = $message;
  
		  Mage::unregister('wishlist');

		  $this->loadLayout();
		  $toplink = $this->getLayout()->getBlock('top.links')->toHtml();
							
                  $sidebar_block = $this->getLayout()->getBlock('ajax_wishlist_sidebar');
		  $sidebar_block->setTemplate('ajax/wishlist/sidebar.phtml');
                  $sidebar = $sidebar_block->toHtml();
                  $response['sidebar'] = $sidebar;
                                                        
                  $sidebar_block_main = $this->getLayout()->getBlock('wishlist_sidebar_tab');
                  $sidebar_block_main->setTemplate('ajax/sidebar_wishlist.phtml');
                  $sidebar_main = $sidebar_block_main->toHtml();
                  $response['sidebar_main'] = $sidebar_main;
                  $response['itemId'] = $itemID;                                     
		  $response['toplink'] = $toplink;
	 						
		}
		catch (Mage_Core_Exception $e)
                {
		   $response['status'] = 'ERROR';
		   $response['message'] = $this->__('An error occurred while deleting item to wishlist: %s', $e->getMessage());
		}
		catch (Exception $e)
                {
		   Mage::log($e->getMessage());
		   $response['status'] = 'ERROR';
		   $response['message'] = $this->__('An error occurred while deleting item to wishlist.');
		}
              
					
	      }
              
        }
        
        $this->getResponse()->setBody(Mage::helper('core')->jsonEncode($response));
	return;
    }
    
     /**
     * Add wishlist item to shopping cart and remove from wishlist
     *
     * If Product has required options - item removed from wishlist and redirect
     * to product view page with message about needed defined required options
     */
    public function cartAction()
    {
         
        $params = $this->getRequest()->getParams();
      if($params['isAjax'] == 1){
            $response = array();
            
            if (!$this->_validateFormKey()) {
                //return $this->_redirect('*/*');
                 $response['status'] = 'ERROR';
                 $response['message'] = $this->__('Plaese reload page');
            }
            $itemId = (int) $this->getRequest()->getParam('item');

            /* @var $item Mage_Wishlist_Model_Item */
            $item = Mage::getModel('wishlist/item')->load($itemId);
            if (!$item->getId()) {
                //return $this->_redirect('*/*');
                $response['status'] = 'ERROR';
                $response['message'] = $this->__('Invalid Wishlist Item');
            }
            $wishlist = $this->_getWishlist($item->getWishlistId());
            if (!$wishlist) {
                // return $this->_redirect('*/*');
                $response['status'] = 'ERROR';
                $response['message'] = $this->__('Wishlist item is not found');
            }

            // Set qty
            $qty = $this->getRequest()->getParam('qty');
            if (is_array($qty)) {
                if (isset($qty[$itemId])) {
                    $qty = $qty[$itemId];
                } else {
                    $qty = 1;
                }
            }
            $qty = $this->_processLocalizedQty($qty);
        
            if ($qty) {
                $item->setQty($qty);
            }
           

            /* @var $session Mage_Wishlist_Model_Session */
            $session    = Mage::getSingleton('wishlist/session');
            $cart       = Mage::getSingleton('checkout/cart');

            // $redirectUrl = Mage::getUrl('*/*');

            try {
               
                $options = Mage::getModel('wishlist/item_option')->getCollection()
                        ->addItemFilter(array($itemId));
                $item->setOptions($options->getOptionsByItem($itemId));

                $buyRequest = Mage::helper('catalog/product')->addParamsToBuyRequest(
                    $this->getRequest()->getParams(),
                    array('current_config' => $item->getBuyRequest())
                );
                if(!version_compare(Mage::getVersion(), '1.6.0', '<='))
                {
                    $item->mergeBuyRequest($buyRequest);
                }
               
                if ($item->addToCart($cart, true)) {
                    $cart->save()->getQuote()->collectTotals();
                }

                $wishlist->save();
               
                $product = $this->getRequest()->getParam('product');
                $productId = $product;
                
                
                
              
                 $product = Mage::getModel('catalog/product')
                ->setStoreId(Mage::app()->getStore()->getId())
                ->load($productId);
             
                 if (!$product)
                 {
                    $response['status'] = 'ERROR';
                    $response['message'] = $this->__('Unable to find Product ID');
                 }
            
                 Mage::getSingleton('checkout/session')->setCartWasUpdated(true);
               
                 /**
                   * @todo remove wishlist observer processAddToCart
		 */
                Mage::dispatchEvent('checkout_cart_add_product_complete',
                    array('product' => $product, 'request' => $this->getRequest(), 'response' => $this->getResponse())
		);
                 
                
                 
                Mage::helper('wishlist')->calculate();
                
                $quote = Mage::getSingleton('checkout/cart')->getQuote();
                $productitem = $quote->getItemByProduct($product);
                if ($productitem !== false)
                {
                    $response['cardId'] =  $productitem->getId(); 
                }   
                else
                {
                   $response['cardId'] =  '';
                }

                if (Mage::helper('checkout/cart')->getShouldRedirectToCart()) {
                    $redirectUrl = Mage::helper('checkout/cart')->getCartUrl();
                } else if ($this->_getRefererUrl()) {
                    $redirectUrl = $this->_getRefererUrl();
                }
                
                if (!$cart->getQuote()->getHasError())
                {
                    $message = $this->__('%s was added to your shopping cart.', Mage::helper('core')->htmlEscape($product->getName()));
                    $response['status'] = 'SUCCESS';
                    $response['message'] = $message;
                    //New Code Here
                    $this->loadLayout();
                    $toplink = $this->getLayout()->getBlock('top.links')->toHtml();
                  //  $wishlistView = $this->getLayout()->getBlock('ajax.wishlist')->toHtml();
                    $sidebar_block = $this->getLayout()->getBlock('cart_sidebar');
                    Mage::register('referrer_url', $this->_getRefererUrl());
                    $sidebar = $sidebar_block->toHtml();
                    $response['toplink'] = $toplink;
                    $response['sidebar'] = $sidebar;
                    //$response['wishlistview'] = $wishlistView;
		}
                
                Mage::helper('wishlist')->calculate();
            }
            catch (Mage_Core_Exception $e)
            {
                $msg = "";
                if ($e->getCode() == Mage_Wishlist_Model_Item::EXCEPTION_CODE_NOT_SALABLE) {
                   $msg = $this->__('This product(s) is currently out of stock');
                } else if ($e->getCode() == Mage_Wishlist_Model_Item::EXCEPTION_CODE_HAS_REQUIRED_OPTIONS) {
                    $msg = $e->getMessage();
                    //  $redirectUrl = Mage::getUrl('*/*/configure/', array('id' => $item->getId()));
                } else {
                    $msg =  $e->getMessage();
                    // $redirectUrl = Mage::getUrl('*/*/configure/', array('id' => $item->getId()));
                }
                
                $response['status'] = 'ERROR';
		$response['message'] = $msg;
            } 
            catch (Exception $e)
            {
                Mage::logException($e);
                $msg = $this->__('Cannot add item to shopping cart');
                $response['status'] = 'ERROR';
		$response['message'] = $msg;
                
            }

            Mage::helper('wishlist')->calculate();

            //return $this->_redirectUrl($redirectUrl);
        }
    else
    {
            Mage_Wishlist_IndexController::cartAction();
    }
        
    $this->getResponse()->setBody(Mage::helper('core')->jsonEncode($response));
    return;    
        
    }
    
    
    
    
}