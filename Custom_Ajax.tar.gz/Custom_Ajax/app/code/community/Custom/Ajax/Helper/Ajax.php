<?php

class Custom_Ajax_Helper_Ajax extends Mage_Core_Helper_Abstract
{

   public function myfun()
   {
       return true;
   }
    
}