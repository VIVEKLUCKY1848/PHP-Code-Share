<?php
class Custom_Ajax_Block_Cart_Sidebar extends Mage_Checkout_Block_Cart_Sidebar {
	/*protected function _construct()
	{
		// Add lifetime to your block
		$this->addData(array('cache_lifetime' => 86400)); // 1 day
		// Add cache tags
		$this->addCacheTag(array(
			Mage_Core_Model_Store::CACHE_TAG,
			Mage_Cms_Model_Block::CACHE_TAG,
			Namespace_Modulename_Model_Carousel::CACHE_TAG
		));
	}*/
	
	/*public function getCacheKeyInfo()
	{
		return array(
			'cart_sidebar_tab',
			Mage::app()->getStore()->getId(),
			(int)Mage::app()->getStore()->isCurrentlySecure(),
			Mage::getDesign()->getPackageName(),
			Mage::getDesign()->getTheme('template')
		);
	}*/
	
	public function getItemRenderer($type)
	{
		if (!isset($this->_itemRenders[$type])) {
			$type = 'default';
		}
		if (is_null($this->_itemRenders[$type]['blockInstance'])) {
			$this->_itemRenders[$type]['blockInstance'] = $this->getLayout()
			->createBlock($this->_itemRenders[$type]['block'])
			->setTemplate('ajax/checkout/cart/sidebar/default.phtml')
			->setRenderedBlock($this);
		}
		return $this->_itemRenders[$type]['blockInstance'];
	}
}
