var compare = false;


var comparecount = 0;
var comparelastItem,comparesec;
var comparesecWidth;
var compareunit = 155;


function resetCompareSlider()
{
   comparesec = jQuery('.block-compare-tab .compare-slider #compare-items');
   var compareitemSize = jQuery(".block-compare-tab .compare-slider #compare-items li.item").size();
   
   if(compareitemSize > 3)
   {    
    comparesec.css('left','0px');
    comparesecWidth = comparesec.width(); jQuery(".block-compare-tab .custom-prev").hide(); jQuery(".block-compare-tab .custom-next").show();
    comparelastItem = compareitemSize - 3; 
    comparecount = 0;   
   }
   else
   {
     comparesec.css('left','0px');
     jQuery(".block-compare-tab .custom-prev").hide(); jQuery(".block-compare-tab .custom-next").hide();      
   }
}


jQuery(document).ready(function(){
   
   resetCompareSlider();
   
   jQuery(".block-compare-tab .custom-next").live("click",function() {
            var left = comparesec.css('left');
            left = Math.abs(parseInt(left.substring(0, left.length - 2)));
            if(comparecount != comparelastItem)
            {
                comparesec.stop(true,true).animate({left: "-=" + compareunit }, "slow");
                jQuery(".block-compare-tab .custom-prev").show();
                comparecount++;
            }
            if(comparecount === comparelastItem)
            {
               jQuery(this).hide()
            }
        });
    
    
   jQuery(".block-compare-tab .custom-prev").live("click",function() {
           var left = comparesec.css('left');
           if(comparecount != 0)
           {
                comparesec.stop(true,true).animate({left: "+=" + compareunit }, "slow");
                jQuery(".block-compare-tab .custom-next").show();
                comparecount--;
            }  
        
            if(comparecount == 0)
            {
                jQuery(this).hide()
            }
    });
   
   
   
    jQuery(".block-compare-tab .block-title").live("click",function(){	
    	jQuery(".account-login-home").stop(true, true).animate({right:'-506px'},'slow').removeClass("show");
    	jQuery(".contact-main").stop(true, true).animate({right:'-506px'},'slow').removeClass("show");
    	jQuery(".block-cart-header").stop(true, true).animate({right:'-506px'},'slow').removeClass("show");
    	jQuery(".block-wishlist").stop(true, true).animate({right:'-506px'},'slow').removeClass("show");
    	//jQuery(".block-compare").stop(true, true).animate({right:"-506px"},"slow").removeClass("show");
    	if (!compare) {
    		jQuery(".block-compare-tab").stop(true, true).animate({right:'-5px'},'slow');
    		jQuery(".block-compare-tab").addClass("show");
    		login = false;
    		contact = false;
    		cart = false;
    		wishlist = false;
    		compare = true;
    	} else {
    		jQuery(".block-compare-tab").stop(true, true).animate({right:'-506px'},'slow');
    		jQuery(".block-compare-tab").removeClass("show");
    		compare = false;
    	}
    }); 
});


function ajaxCompare(url,id){
	url = url.replace("catalog/product_compare/add","ajax/whishlist/compare");
	url += 'isAjax/1/';
         jQuery('body').append('<div id="custom-loading"><div></div></div>');

	jQuery.ajax( {
		url : url,
		dataType : 'json',
		success : function(data) {
                        if(data.status == 'ERROR') {
				jQuery('body').append('<div class="alert"></div>');
				jQuery('.alert').slideDown(400);
				jQuery('.alert').html(data.message).append('<button></button>');
                                jQuery('.alert').slideDown('400',function() {
					setTimeout(function(){
						jQuery('.alert').slideUp('400',function(){jQuery('#custom-loading').remove(); jQuery(this).remove();});
					},7000)
				});
			} else {
				jQuery('body').append('<div class="alert"></div>');
				jQuery('.alert').slideDown(400);
				jQuery('.alert').html(data.message).append('<button></button>');
				
				
				jQuery('.block-compare-tab').replaceWith(data.sidebar_tab);
				if(jQuery('.block-compare').length) {
					jQuery('.block-compare').replaceWith(data.sidebar_main);
                                        resetCompareSlider();
                                        
                                } /*else  {
                                    if(jQuery('.col-right').length) {
                                            jQuery('.col-right').prepend(data.sidebar);
                                    }
                                }*/
                                        
                               jQuery('.alert').slideDown('400',function() {
					setTimeout(function() {
						jQuery('.alert').slideUp('400',function(){jQuery('#custom-loading').remove(); jQuery(this).remove()});
						jQuery(".block-compare-tab").stop(true, true).animate({right:'0px'},'slow').delay(1000).animate({right:'-506px'},'slow');
						jQuery(".block-compare-tab").addClass("show");
					},1000)
				});         
                               
                              
			}
		}
	});
}

function DeleteCompareItem(thisobj)
{
   if(confirm('Are you sure you would like to remove this item from the compare products?'))
   {
      
     var url = jQuery(thisobj).attr('href');
     url = url.replace('catalog/product_compare/remove','ajax/whishlist/removeitem');
     url += 'isAjax/1';  
     jQuery('body').append('<div id="custom-loading"><div></div></div>');
     jQuery.ajax({
	url : url,
	dataType : 'json',
	success : function(data)
        {
             compare = false;
            if(data.status == 'ERROR')
            {
		jQuery('body').append('<div class="alert"></div>');
		jQuery('.alert').slideDown(400);
		jQuery('.alert').html(data.message).append('<button></button>');
		jQuery('button').click(function (){
                    jQuery('.alert').slideUp(400);
                });

                jQuery('.alert').slideDown('400',function()
                {
                    setTimeout(function(){jQuery('.alert').slideUp('400',function(){loading.remove(); jQuery(this).slideUp(400)});},7000)
                });
            }
            else
            {
		jQuery('body').append('<div class="alert"></div>');
		jQuery('.alert').slideDown(400);
		jQuery('.alert').html(data.message).append('<button></button>');
		jQuery('button').click(function () { jQuery('.alert').remove(); });
				
               
		//alert("lenght=="+jQuery('.block-compare').length);		
		//if(jQuery('.block-compare').length)
               // {
                   var compareHtml = jQuery(data.sidebar_tab).html();
                   var block_content = jQuery(data.sidebar_tab).find(".block-content").html();
                   if(jQuery.trim(block_content) == '')
                   {
                       jQuery('.block-compare-tab').replaceWith(data.sidebar_tab);
                       
                   }
                   else
                   {
                       jQuery('.block-compare-tab').html(compareHtml);
                   }
                   
                   resetCompareSlider();
               // }                                
                
               // if(jQuery('.block-compare').length)
               // {
               //     alert("test2");
		    jQuery('.block-compare').replaceWith(data.sidebar_main);
               // }
               
                jQuery('.alert').slideDown('400',function() {
                    setTimeout(function() { 
                         jQuery('.alert').slideUp('400',function(){jQuery("#custom-loading").remove(); jQuery(this).remove()});
                     
                         if(data.totalItem)
                         {    
                          jQuery(".block-compare-tab").stop(true, true).animate({right:'0px'},'slow').delay(1000).animate({right:'-506px'},'slow');
			 }
			},2000);
                      
                            
		});
                              
              }
           }
	});
    }
  return false;
}

function deleteAll(thisObj)
{
    //return confirm('Are you sure you would like to remove all products from your comparison?');
  
  if(confirm('Are you sure you would like to remove all products from your comparison?'))
   {
     var url = jQuery(thisObj).attr('href');
     url = url.replace('catalog/product_compare/clear','ajax/whishlist/clearcompare');
     url += 'isAjax/1';
       jQuery('body').append(loading = jQuery('<div id="custom-loading"><div></div></div>'));
     jQuery.ajax({
	url : url,
	dataType : 'json',
	success : function(data)
        {
            compare = false;
            if(data.status == 'ERROR')
            {
		jQuery('body').append('<div class="alert"></div>');
		jQuery('.alert').slideDown(400);
		jQuery('.alert').html(data.message).append('<button></button>');
		jQuery('button').click(function (){
                    jQuery('.alert').slideUp(400);
                });

                jQuery('.alert').slideDown('400',function()
                {
                    setTimeout(function(){jQuery('.alert').slideUp('400',function(){loading.remove(); jQuery(this).slideUp(400)});},7000)
                });
            }
            else
            {
		jQuery('body').append('<div class="alert"></div>');
		jQuery('.alert').slideDown(400);
		jQuery('.alert').html(data.message).append('<button></button>');
		jQuery('button').click(function () { jQuery('.alert').remove(); });
				
                jQuery('.alert').slideDown('400',function() {
                    setTimeout(function() { 
                         jQuery('.alert').slideUp('400',function(){loading.remove(); jQuery(this).remove()});
			 jQuery(".block-compare-tab").stop(true, true).delay(1000).animate({right:'-506px'},'slow');
			 jQuery(".block-compare-tab").addClass("show");
			},1000)
		});
				
		//if(jQuery('.block-compare').length)
               // {
		    jQuery('.block-compare-tab').replaceWith(data.sidebar_tab);
               // }                                
                
               // if(jQuery('.block-compare').length)
               // {
		    jQuery('.block-compare').replaceWith(data.sidebar_main);
                //}
                              
              }
           }
	});     
   }
  
 return false;
}