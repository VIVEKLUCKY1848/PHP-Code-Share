var login = false;
var contact = false;
var cart = false;
var Cartitemcount = 0;
var lastItem, sec;
var secWidth;
var unit = 155;

function resetSlider() {
    sec = jQuery('.block-cart-header .cart-slider #cart-sidebar');
    var itemSize = jQuery(".block-cart-header .cart-slider #cart-sidebar li.item").size();
    if (itemSize > 3) {
        sec.css('left', '0px');
        secwidth = sec.width();
        jQuery(".block-cart-header .custom-prev").hide();
        jQuery(".block-cart-header .custom-next").show();
        lastItem = itemSize - 3;
        Cartitemcount = 0;
    } else {
        sec.css('left', '0px');
        jQuery(".block-cart-header .custom-prev").hide();
        jQuery(".block-cart-header .custom-next").hide();
    }
    setSummaryClick();
}
jQuery('document').ready(function() {
    resetSlider();
    jQuery(".block-cart-header .custom-next").live("click", function() {
        var left = sec.css('left');
        left = Math.abs(parseInt(left.substring(0, left.length - 2)));
        if (Cartitemcount != lastItem) {
            sec.stop(true, true).animate({
                left: "-=" + unit
            }, "slow");
            jQuery(".block-cart-header .custom-prev").show();
            Cartitemcount++;
        }
        if (Cartitemcount === lastItem) {
            jQuery(this).hide()
        }
    });
    jQuery(".block-cart-header .custom-prev").live("click", function() {
        var left = sec.css('left');
        if (Cartitemcount != 0) {
            sec.stop(true, true).animate({
                left: "+=" + unit
            }, "slow");
            jQuery(".block-cart-header .custom-next").show();
            Cartitemcount--;
        }
        if (Cartitemcount == 0) {
            jQuery(this).hide()
        }
    });
    jQuery(".btn-log").click(function() {
        //jQuery(".account-login-home").stop(true, true).animate({right:'-506px'},'slow').removeClass("show");
        jQuery(".contact-main").stop(true, true).animate({
            right: '-506px'
        }, 'slow').removeClass("show");
        jQuery(".block-cart-header").stop(true, true).animate({
            right: '-506px'
        }, 'slow').removeClass("show");
        jQuery(".sidebar-wishlist").stop(true, true).animate({
            right: '-506px'
        }, 'slow').removeClass("show");
        jQuery(".block-compare-tab").stop(true, true).animate({
            right: "-506px"
        }, "slow").removeClass("show");
        if (!login) {
            jQuery(".account-login-home").stop(true, true).animate({
                right: '-5px'
            }, 'slow');
            jQuery(".account-login-home").addClass("show");
            login = true;
            contact = false;
            cart = false;
            wishlist = false;
            compare = false;
        } else {
            jQuery(".account-login-home").stop(true, true).animate({
                right: '-506px'
            }, 'slow');
            jQuery(".account-login-home").removeClass("show");
            login = false;
        }
    });
    // Contact Sidebar tab
    jQuery(".btn-contact").click(function() {
        jQuery(".account-login-home").stop(true, true).animate({
            right: '-506px'
        }, 'slow').removeClass("show");
        //jQuery(".contact-main").stop(true, true).animate({right:'-506px'},'slow').removeClass("show");
        jQuery(".block-cart-header").stop(true, true).animate({
            right: '-506px'
        }, 'slow').removeClass("show");
        jQuery(".sidebar-wishlist").stop(true, true).animate({
            right: '-506px'
        }, 'slow').removeClass("show");
        jQuery(".block-compare-tab").stop(true, true).animate({
            right: "-506px"
        }, "slow").removeClass("show");
        if (!contact) {
            jQuery(".contact-main").stop(true, true).animate({
                right: '-5px'
            }, 'slow');
            jQuery(".contact-main").addClass("show");
            login = false;
            contact = true;
            cart = false;
            wishlist = false;
            compare = false;
        } else {
            jQuery(".contact-main").stop(true, true).animate({
                right: '-506px'
            }, 'slow');
            jQuery(".contact-main").removeClass("show");
            contact = false;
        }
    });
});

function setSummaryClick() {
	    jQuery(".block-cart-header .summary").click(function() {
        jQuery(".account-login-home").stop(true, true).animate({
            right: '-506px'
        }, 'slow').removeClass("show");
        jQuery(".contact-main").stop(true, true).animate({
            right: '-506px'
        }, 'slow').removeClass("show");
        //jQuery(".block-cart-header").stop(true, true).animate({right:'-506px'},'slow').removeClass("show");
        jQuery(".sidebar-wishlist").stop(true, true).animate({
            right: '-506px'
        }, 'slow').removeClass("show");
        jQuery(".block-compare-tab").stop(true, true).animate({
            right: "-506px"
        }, "slow").removeClass("show");
        if (!cart) {
            jQuery(".block-cart-header").addClass("show");
            jQuery(".block-cart-header").stop(true, true).animate({
                right: '-5px'
            }, 'slow');
            login = false;
            contact = false;
            cart = true;
            wishlist = false;
            compare = false;
        } else {
            jQuery(".block-cart-header").stop(true, true).animate({
                right: '-506px'
            }, 'slow');
            jQuery(".block-cart-header").removeClass("show");
            cart = false;
        }
    });
}

function showOptions(id) {
    jQuery('#fancybox' + id).trigger('click');
}

function setAjaxData(data, iframe) {
    var curUrl = window.location.href;
    var cartItem = '', cartAction = '';
    var sidebarData = data.sidebar;

    sidebarData = sidebarData.replace(/\\/g, "");

    cartItem = jQuery(sidebarData).find('#cart-sidebar').html();
    cartTotal = jQuery(sidebarData).find('.block-content  .subtotal').html();
    itemCount = jQuery(sidebarData).find('.block-content  .amount a').html();
    itemCount = itemCount.replace(/[^\d.]/g, '');
    itemCount = parseInt(itemCount);
    if (data.status == 'ERROR') {
        alert(data.message);
    } else {
        if (jQuery('.block-cart')) {
            jQuery('.block-cart').replaceWith(sidebarData);
        }
        /*if(jQuery('.block-cart-header')) {
        	jQuery('.block-cart-header').replaceWith(data.sidebar_header);
        }*/
        if (jQuery('.block-cart-header #cart-sidebar')) {
            jQuery('.block-cart-header #cart-sidebar').html(cartItem);
            jQuery('.block-cart-header .cart-content .actions .subtotal').html(cartTotal);
            jQuery('.block-cart-header .block-content a#blocksummary').addClass('showbox');
            jQuery('.block-cart-header .block-content a#blocksummary span').html(itemCount);
            jQuery('.block-cart-header .cart-content').show();
        }
        if (jQuery('.header .links')) {
            jQuery('.header .links').replaceWith(data.toplink);
        }
        jQuery.fancybox.close();
    }
}

function setLocationAjax(url, id) {
    if (jQuery('#qty_' + id + '')) {
        var qty = jQuery('#qty_' + id + '').val();
        if (qty) {
            url += 'qty/' + qty + '/';
        }
    }
    url += 'isAjax/1';
    url = url.replace("checkout/cart", "ajax/index");
    var loading = '';
    url = url.replace("wishlist/index", "ajax/whishlist");
    jQuery('body').append('<div id="custom-loading"><div></div></div>');
    var alertbox;
    var cartItem = '',
        cartAction = '',
        itemCount = '',
        cartId = '',
        existItem = '';
    try {
        jQuery.ajax({
            url: url,
            dataType: 'json',
            success: function(data) {
                if (data.status == 'ERROR') {
                    jQuery('body').append(alertbox = jQuery('<div class="alert">&nbsp;</div>'));
                    jQuery('.alert').html(data.message).append('<button>&nbsp;</button>');
                    jQuery('.block-cart-header .amount-2 a').hover(function() {
                        jQuery('.block-cart-header .cart-content').stop(true, true).slideDown(100);
                    }, function() {
                        jQuery('.block-cart-header .cart-content').stop(true, true).delay(100).slideUp(100);
                    });
                    jQuery('.block-cart-header').show();
                    jQuery('.alert').slideDown('100', function() {
                        setTimeout(function() {
                            jQuery('.alert').slideUp('100', function() {
                                jQuery('#custom-loading').remove();
                                jQuery(this).remove();
                            });
                        }, 1000);
                    });
                } else {
                    jQuery('body').append('<div class="alert">&nbsp;</div>');
                    jQuery('.alert').slideDown(400);
                    jQuery('.alert').html(data.message).append('<button>&nbsp;</button>');
                    jQuery('.block-cart-header .block-content a#blocksummary').removeClass('hidebox');
                    /*jQuery('.block-cart-header').empty();
                    jQuery('.block-cart-header').append(data.sidebar);*/
                    jQuery('.block-cart-header').html(data.sidebar);

                    jQuery('.alert').slideDown('400', function() {
                        setTimeout(function() {
                            jQuery('.alert').slideUp('400', function() {
                                if (jQuery('#custom-loading').html()) {
                                    jQuery('#custom-loading').remove();
                                }
                            });
                            jQuery('.block-cart-header').stop(true, true).animate({
                                right: '0px'
                            }, 'slow').delay(2000).animate({
                                right: '-506px'
                            }, 'slow');
                            jQuery('.block-cart-header').show();
                        }, 1000);
                    });
										resetSlider();

                    /*jQuery('.block-cart-header .cart-content').hide();
                    jQuery('.block-cart-header  .amount-2 a').hover(function() {
                        jQuery('.block-cart-header .cart-content').stop(true, true).slideDown(400);
                    }, function() {
                        jQuery('.block-cart-header .cart-content').stop(true, true).delay(400).slideUp(300);
                    });
                    var sidebarData = data.sidebar;
                    sidebarData = sidebarData.replace(/\\/g, "");
                    data.sidebar = sidebarData;

                    if (jQuery('.block-cart')) {
                        jQuery('.block-cart').replaceWith(data.sidebar);
                        resetSlider();
                    }
                    cartItem = jQuery(data.sidebar).find('ol#cart-sidebar li:first').html();
                    cartTotal = jQuery(data.sidebar).find('.block-content .subtotal').html();
                    itemCount = jQuery(data.sidebar).find('.block-content #blocksummary span').html();
                    itemCount = itemCount.replace(/[^\d.]/g, '');
                    itemCount = parseInt(itemCount);
                    if (jQuery('.block-cart-header #cart-sidebar')) {
                        cartId = data.cardId;
                        existItem = jQuery('.block-cart-header ol#cart-sidebar').find('li#cart_' + cartId + '');
                        if (existItem && jQuery.trim(existItem.html()) != '') {
                            var curQty = existItem.find('.product_qty').html();
                            curQty = parseInt(curQty) + parseInt(data.qty);
                            existItem.find('.product_qty').html(curQty);
                        } else {
                            jQuery('.block-cart-header ol#cart-sidebar').prepend('<li class="item" id="cart_' + cartId + '">' + cartItem + '</li>');
                        }
                        cart = false;
                        jQuery('.block-cart-header .cart-content .actions .subtotal').html(cartTotal);
                        //resetSlider();
                        jQuery('.block-cart-header .block-content a#blocksummary').addClass('showbox');
                        jQuery('.block-cart-header .block-content a#blocksummary span').html(itemCount);
                        jQuery('.block-cart-header .cart-content').show();
                    }*/

                    if (jQuery('.my-wishlist').html()) {
                        //  jQuery('#item_'+id+'').remove();
                        var tr = jQuery('#wishlist-table tbody tr');
                        var classname = 'odd';
                        resetWishlistSlider();
                        if (tr.length == 0) {
                            jQuery('#wishlist-view-form').html('<p class="wishlist-empty">You have no items in your wishlist.</p><div class="buttons-set buttons-set2"> </div>');
                        }
                        tr.each(function(i, row) {
                            jQuery(row).removeClass('odd').removeClass('even');
                            jQuery(row).addClass(classname);
                            if (classname == 'odd') {
                                classname = 'even';
                            } else {
                                classname = 'odd';
                            }
                        });
                    }
                    if (jQuery('ol#wishlist-sidebar li.item').length) {
                        var removeWishlistobj = jQuery('ol#wishlist-sidebar li.item_' + id + ' a.btn-remove');
                        if (removeWishlistobj.attr('href')) {
                            removeWishlist(removeWishlistobj, 'wishlist');
                        }
                    }
                    if (jQuery('.cart').html()) {
                        jQuery.ajax({
                            url: curUrl,
                            dataType: 'html',
                            method: 'post',
                            success: function(htmlData) {
                                if (!itemCount || itemCount == 0) {
                                    var html = jQuery(htmlData).find('.main').html();
                                    jQuery('.main').html(html);
                                } else {
                                    var html = jQuery(htmlData).find('.cart').html();
                                    jQuery('.cart').html(html);
                                }
                            }
                        });
                    }
                    if (jQuery('.header .links')) {
                        jQuery('.header .links').replaceWith(data.toplink);
                    }
                }
            }
        });
    } catch (e) {}
}

function deleteCartItem(thisobj) {
    if (confirm('Are you sure you would like to remove this item from the shopping cart?')) {
        var url = jQuery(thisobj).attr('href');
        var curUrl = window.location.href;
        var cartItem = ''; //jQuery(thisobj).parent().parent('li.item');
        var loading;
        jQuery('body').append('<div id="custom-loading"><div></div></div>');
        url = url.replace('checkout/cart/delete', 'ajax/index/delete');
        url += 'isAjax/1';
        try {
            jQuery.ajax({
                url: url,
                dataType: 'json',
                method: 'post',
                success: function(data) {
                    cart = false;
                    if (data.status == 'ERROR') {
                        jQuery('body').append(alertbox = jQuery('<div class="alert">&nbsp;</div>'));
                        jQuery('.alert').slideDown(100);
                        jQuery('.alert').html(data.message).append('<button>&nbsp;</button>');

												/*jQuery('button').click(function () {
													jQuery('#custom-loading').remove();
													jQuery('.alert').remove();
												});*/

                        jQuery('.block-cart-header .amount-2 a').hover(function() {
                            jQuery('.block-cart-header .cart-content').stop(true, true).slideDown(100);
                        }, function() {
                            jQuery('.block-cart-header .cart-content').stop(true, true).delay(100).slideUp(100);
                        });

                        jQuery(".block-cart-header").stop(true, true).animate({
                            right: '0px'
                        }, 'slow').delay(1000).animate({
                            right: '-506px'
                        }, 'slow');

                        jQuery('.alert').slideDown('100', function() {
                            setTimeout(function() {
                                jQuery('.alert').slideUp('100', function() {
                                    jQuery('#custom-loading').remove();
                                    jQuery(this).remove();
                                });
                                jQuery('.block-cart-header').stop(true, true).animate({
                                    right: '0px'
                                }, 'slow').delay(1000).animate({
                                    right: '-506px'
                                }, 'slow');
                                jQuery('.block-cart-header').show();
                            }, 1000);
                        });
                    } else {
                        jQuery('body').append('<div class="alert">&nbsp;</div>');
                        jQuery('.alert').html(data.message).append('<button>&nbsp;</button>');
                        /*jQuery('button').click(function () {jQuery('.alert').remove();}); */
                        cartItem = data.cartid;
                        jQuery('#cart_' + cartItem).remove();
                        //cartItem.remove();
                        lastItem = lastItem - 1;
                        jQuery('.block-cart-header .cart-content').hide();
                        jQuery('.block-cart-header  .amount-2 a').hover(function() {
                            jQuery('.block-cart-header .cart-content').stop(true, true).slideDown(400);
                        }, function() {
                            jQuery('.block-cart-header .cart-content').stop(true, true).delay(400).slideUp(300);
                        });
                        if (jQuery('.block-cart')) {
                            jQuery('.block-cart').replaceWith(data.sidebar);
                        }
                        cartItem = jQuery(data.sidebar).find('#cart-sidebar').html();
                        cartTotal = jQuery(data.sidebar).find('.block-content .subtotal').html();
                        itemCount = jQuery(data.sidebar).find('.block-content .amount a').html();
                        if (itemCount) {
                            itemCount = itemCount.replace(/[^\d.]/g, '');
                            itemCount = parseInt(itemCount);
                            jQuery('.block-cart-header .block-content a#blocksummary').removeClass('hidebox');
                            jQuery('.block-cart-header .block-content a#blocksummary').addClass('showbox');
                        } else {
                            itemCount = 0;
                            jQuery('.block-cart-header').css('right', '-506px');
                            jQuery('.block-cart-header .block-content a#blocksummary').removeClass('showbox');
                            jQuery('.block-cart-header .block-content a#blocksummary').addClass('hidebox');
                        }
                        jQuery('.alert').slideDown('100', function() {
                            setTimeout(function() {
                                jQuery('.alert').slideUp('100', function() {
                                    jQuery(this).remove();
                                    jQuery('#custom-loading').remove();
                                });
                                if (itemCount !== 0) {
                                    jQuery('.block-cart-header').show();
                                }
                                jQuery('.block-cart-header').stop(true, true).animate({
                                    right: '-506px'
                                }, 'slow');
                            }, 1000);
                        });
                        if (jQuery('.block-cart-header #cart-sidebar')) {
                            resetSlider();
                            jQuery('.block-cart-header #cart-sidebar').html(cartItem);
                            jQuery('.block-cart-header .cart-content .actions .subtotal').html(cartTotal);
                            jQuery('.block-cart-header .block-content a#blocksummary span').html(itemCount);
                            jQuery('.block-cart-header .cart-content').show();
                        }
                        if (jQuery('.cart').html()) {
                            jQuery.ajax({
                                url: curUrl,
                                dataType: 'html',
                                method: 'post',
                                success: function(htmlData) {
                                    if (!itemCount || itemCount == 0) {
                                        var html = jQuery(htmlData).find('.main').html();
                                        jQuery('.main').html(html);
                                    } else {
                                        var html = jQuery(htmlData).find('.cart').html();
                                        jQuery('.cart').html(html);
                                    }
                                }
                            });
                        }
                        if (jQuery('#opc-review')) {
                            if (jQuery('#opc-review').hasClass('active')) {
                                checkout.gotoSection('billing');
                            }
                        }
                        if (jQuery('.header .links')) {
                            jQuery('.header .links').replaceWith(data.toplink);
                        }
                    }
                }
            });
        } catch (e) {
            alert("Please Try again");
        }
    }
    return false;
}
// Upsell product carousel
/*jQuery(function() {
	jQuery(".box-up-sell").jcarousel({
		vertical: false,
		visible:3,
		scroll: 1
	});
});
// Media Gallery Lightbox
jQuery(function() {
	jQuery("a[data-gal^='prettyPhoto']").prettyPhoto({
		animationSpeed:"slow",theme:"facebook",slideshow:12000, autoplay_slideshow: true, width:500,height:500, opacity:0.7, padding:60
	});
});
// Wishlist and compare tooltip
jQuery(function() {
	jQuery('a.tooltips').easyTooltip();
});
// Quick view
jQuery(function(){
	jQuery('.fancybox').fancybox({
		hideOnContentClick : true,
		width:800,
		autoDimensions: true,
        type : 'iframe',
		showTitle: true,
		scrolling: 'no',
		onComplete: function(){
			jQuery('#fancybox-frame').load(function() {
				jQuery('#fancybox-content').height(jQuery(this).contents().find('body').height()+30);
				jQuery.fancybox.resize();
			});
		}
	});
});
*/
