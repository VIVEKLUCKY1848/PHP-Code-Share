function ajax_filter(thisObj)
{
    var url = jQuery(thisObj).attr('href');
    var loading ='';
    jQuery('body').append(loading = jQuery('<div id="custom-loading"><div></div></div>'));
   jQuery.ajax({
		url : url,
		dataType : 'html',
		success : function(data) {
                    var layerd_leftblock = jQuery(data).find('.block-layered-nav').html();
                    var layerd_product = jQuery(data).find('.category-products').html();
                    jQuery('.block-layered-nav').html(layerd_leftblock);
                    jQuery('.category-products').html(layerd_product);
                    loading.remove();
                    ajaxtoolbar.onReady();
                    return false;
                }
		});
   
   return false;
}