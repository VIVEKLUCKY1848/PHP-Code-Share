var wishlist = false;

var wishlistcount = 0;
var wishlistlastItem,wishlistsec;
var wishlistsecWidth;
var wishlistunit = 155;


function resetWishlistSlider()
{
   wishlistsec = jQuery('.sidebar-wishlist .wishlist-slider #wishlist-sidebar');
   var wishlistitemSize = jQuery(".sidebar-wishlist .wishlist-slider #wishlist-sidebar li.item").size();
   
   if(wishlistitemSize > 3)
   {    
    wishlistsec.css('left','0px');
    wishlistsecWidth = wishlistsec.width(); jQuery(".sidebar-wishlist .custom-prev").hide(); jQuery(".sidebar-wishlist .custom-next").show();
    wishlistlastItem = wishlistitemSize - 3; 
    wishlistcount = 0;   
   }
   else
   {
     wishlistsec.css('left','0px');
     jQuery(".sidebar-wishlist .custom-prev").hide(); jQuery(".sidebar-wishlist .custom-next").hide();      
   }
}


jQuery(document).ready(function(){
    resetWishlistSlider();
    jQuery(".sidebar-wishlist .custom-next").live("click",function() {
            var left = wishlistsec.css('left');
            left = Math.abs(parseInt(left.substring(0, left.length - 2)));
            if(wishlistcount != wishlistlastItem)
            {
                wishlistsec.stop(true,true).animate({left: "-=" + wishlistunit }, "slow");
                jQuery(".sidebar-wishlist .custom-prev").show();
                wishlistcount++;
            }
            if(wishlistcount === wishlistlastItem)
            {
               jQuery(this).hide()
            }
        });
    
    
   jQuery(".sidebar-wishlist .custom-prev").live("click",function() {
           var left = wishlistsec.css('left');
           if(wishlistcount != 0)
           {
                wishlistsec.stop(true,true).animate({left: "+=" + wishlistunit }, "slow");
                jQuery(".sidebar-wishlist .custom-next").show();
                wishlistcount--;
            }  
        
            if(wishlistcount == 0)
            {
                jQuery(this).hide()
            }
    });


    jQuery(".sidebar-wishlist .block-title").live("click",function(){
            jQuery(".account-login-home").stop(true, true).animate({right:'-506px'},'slow').removeClass("show");
            jQuery(".contact-main").stop(true, true).animate({right:'-506px'},'slow').removeClass("show");
            jQuery(".block-cart-header").stop(true, true).animate({right:'-506px'},'slow').removeClass("show");
		//jQuery(".block-wishlist").stop(true, true).animate({right:'-506px'},'slow').removeClass("show");
            jQuery(".block-compare-tab").stop(true, true).animate({right:"-506px"},"slow").removeClass("show");
		
            if (!wishlist) 
            {
            	jQuery(".sidebar-wishlist").stop(true, true).animate({right:'-5px'},'slow');
		jQuery(".sidebar-wishlist").addClass("show");
		login = false;
		contact = false;
		cart = false;
		wishlist = true;
		compare = false;
            }
            else 
            {
		jQuery(".sidebar-wishlist").stop(true, true).animate({right:'-506px'},'slow');
		jQuery(".sidebar-wishlist").removeClass("show");
		wishlist = false;
            }
	});
});
function ajaxWishlist(url,id){
	url = url.replace("wishlist/index","ajax/whishlist");
	url += 'isAjax/1/';
          jQuery('body').append('<div id="custom-loading"><div></div></div>');
	jQuery.ajax( {
		url : url,
		dataType : 'json',
		success : function(data) {
			if(data.status == 'ERROR')
                        {
			    jQuery('body').append('<div class="alert"></div>');
			    jQuery('.alert').slideDown(400);
			    jQuery('.alert').html(data.message).append('<button></button>');
			 /*   jQuery('button').click(function() {
			 	jQuery('.alert').remove(400);
			    });	
			*/	
			    jQuery('.alert').slideDown('400',function(){
				setTimeout(function(){
					jQuery('.alert').slideUp('400',function(){ jQuery('#custom-loading').remove(); jQuery(this).slideUp(400)});
				},1500)
			    });
			}
                        else 
                        {
                            
                             jQuery('body').append('<div class="alert"></div>');
                             jQuery('.alert').slideDown(400);
                             jQuery('.alert').html(data.message).append('<button></button>');
                             jQuery('button').click(function () {
                               	jQuery('.alert').slideUp(400);
                             });	
					
                             jQuery('.alert').slideDown('400',function(){
				setTimeout(function() {
					jQuery('.alert').slideUp('400',function(){ jQuery('#custom-loading').remove(); jQuery(this).remove()});
					jQuery(".sidebar-wishlist").stop(true, true).animate({right:'0px'},'slow').delay(1000).animate({right:'-506px'},'slow');
				},1000)
                              });
					
                              if(jQuery('.block-wishlist').length)
                              {
				jQuery('.block-wishlist').replaceWith(data.sidebar);
                              } 
                              else
                              {
                                jQuery('.footer').prepend(data.sidebar_main);
                                if(jQuery('.col-right').length)
                                {
                                    jQuery('.col-right').prepend(data.sidebar);
                                }
			      }
                               
                              if(jQuery('.block-wishlist').length)
                              {
                                  jQuery('.sidebar-wishlist').replaceWith(data.sidebar_main);
                                  resetWishlistSlider();
                              }
                              
                           
                        
                              if(jQuery('.header .links'))
                              {
                                jQuery('.header .links').replaceWith(data.toplink);
                              }
                              
                              
                            }
			}
		});
	}

function removeWishlist(thisobj,from)
{
     if(from == 'deletewishlist')
      {
      var conformwindow = confirm('Are you sure you would like to remove this item from the wishlist?');        
      }
      else
      {
          conformwindow = 1;
      }
   if(conformwindow)
   {
       var url = jQuery(thisobj).attr('href');
       var loading;
       var id ='';
       jQuery('body').append('<div id="custom-loading"><div></div></div>');
       url = url.replace('wishlist/index/remove','ajax/whishlist/delete');
       url += 'isAjax/1';
        
        jQuery.ajax({
		url : url,
		dataType : 'json',
		success : function(data) {
                    wishlist = false;
                    if(data.status == 'ERROR') {
			jQuery('body').append('<div class="alert"></div>');
			jQuery('.alert').slideDown(400);
			jQuery('.alert').html(data.message).append('<button></button>');
			jQuery('button').click(function() {
				jQuery('.alert').slideUp(400);
			});	
				
			jQuery('.alert').slideDown('400',function(){
				setTimeout(function(){
                                    jQuery('.alert').slideUp('400',function(){ jQuery('#custom-loading').remove(); jQuery(this).slideUp(400)});
                                },1500)
			});
				} else {
					jQuery('body').append('<div class="alert"></div>');
					jQuery('.alert').slideDown(400);
					jQuery('.alert').html(data.message).append('<button></button>');
					jQuery('button').click(function () {
						jQuery('.alert').slideUp(400);
                                                 
					});	
					
					var wishlistHtml = jQuery(data.sidebar).html();
                                        var whishlist_block = jQuery(data.sidebar).find('.block-title').html();
                                 
					if(jQuery('.block-wishlist').length) {
					       if(jQuery.trim(whishlist_block) == '')
                                                {
                                                  jQuery('.block-wishlist').replaceWith(data.sidebar);     
                                                }
                                                else
                                                {
                                                    jQuery('.block-wishlist').html(wishlistHtml);    
                                                }
                                                
                                                
					} else {
                                            jQuery('.footer').prepend(data.sidebar_main);
                                                if(jQuery('.col-right').length){
							jQuery('.col-right').prepend(data.sidebar);
						}
					    
						
					}
                                        
                                        if(jQuery('.block-wishlist'.length)) {
                                            jQuery('.sidebar-wishlist').replaceWith(data.sidebar_main);
                                            resetWishlistSlider();
                                        }
                                        
                                        if(jQuery('.header .links').length)
                                        {
					  jQuery('.header .links').replaceWith(data.toplink);
					}
                                        
                                        if(jQuery('.my-wishlist'))
                                        {
                                            id =data.itemId;
                                            jQuery('#item_'+id+'').remove();
                                            var tr = jQuery('#wishlist-table tbody tr');
                                            var classname = 'odd';
                                            if(tr.length == 0)
                                            {
                                                jQuery('#wishlist-view-form').html('<p class="wishlist-empty">You have no items in your wishlist.</p><div class="buttons-set buttons-set2"> </div>');
                                            }
                         
                                            tr.each(function(i,row)
                                            {
                                                jQuery(row).removeClass('odd').removeClass('even');
                                                jQuery(row).addClass(classname);
                                                if(classname == 'odd'){ classname = 'even'; } else { classname = 'odd'; }
                                            });
                                        }
                                     //if(jQuery('#custom-loading').html()){jQuery('#custom-loading').remove();}  
                                     // jQuery(this).slideUp(400)
                                        jQuery('.alert').slideDown('400',function(){
						setTimeout(function() {
							jQuery('.alert').slideUp('400',function(){ if(jQuery('#custom-loading').html()){jQuery('#custom-loading').remove();} });
						if(from == 'deletewishlist')
                                                {
                                                  jQuery(".sidebar-wishlist").stop(true, true).animate({right:'0px'},'slow').delay(1000).animate({right:'-506px'},'slow');    
                                                }
                                                else
                                                {
                                                 jQuery(".sidebar-wishlist").stop(true, true).delay(1000).animate({right:'-506px'},'slow');       
                                                }
                                                        
                                                        
						},2000)
					});
                                        
				}
			}
		});        
}
   
  return false;     
}